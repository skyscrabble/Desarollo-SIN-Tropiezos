package clases.personajes;

import clases.Capacidad;
import clases.Objeto;
import clases.Ubicacion;

public abstract class Personaje {
	public boolean es_hijo_o_hija;
	public boolean es_padre_o_madre;
	public String estado_libertad;
	public String estado_vida;
	public String nombre;
	public Objeto posee_objeto;
	public Capacidad tiene_capacidad;
	public Personaje tiene_enojo;
	public Personaje tiene_favor;
	public Ubicacion ubicacion_actual;
}
